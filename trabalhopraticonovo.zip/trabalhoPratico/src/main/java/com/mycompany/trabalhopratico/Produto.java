/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.trabalhopratico;

public class Produto {
// Classe que representa um produto do sistema

    private static int contador = 1;
    // Atributo que gera IDs automáticos

    private int id;
    // Armazena o ID do produto

    private String nome;
    // Armazena o nome do produto

    private String descricao;
    // Armazena a descrição do produto

    private double preco;
    // Armazena o preço do produto

    private Categoria categoria;
    // Associação com a classe Categoria

    private Estoque estoque;
    // Associação com a classe Estoque

    public Produto(String nome, String descricao, double preco,
                   Categoria categoria, Estoque estoque) {
    // Construtor da classe

        this.id = contador++;
        // Define o ID automaticamente

        this.nome = nome;
        // Define o nome

        this.descricao = descricao;
        // Define a descrição

        this.preco = preco;
        // Define o preço

        this.categoria = categoria;
        // Define a categoria do produto

        this.estoque = estoque;
        // Define o estoque do produto
    }

    public int getId() {
    // Retorna o ID do produto
        return id;
    }

    public String getNome() {
    // Retorna o nome do produto
        return nome;
    }

    public void atualizarProduto(String nome, String descricao, double preco) {
    // Atualiza as informações do produto
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
    }

    public void exibirInfo() {
    // Exibe as informações do produto

        System.out.println("ID: " + id);
        System.out.println("Nome: " + nome);
        System.out.println("Descrição: " + descricao);
        System.out.printf("Preço: R$ %.2f%n", preco);

        System.out.println("Categoria: " + categoria.getNomeCategoria());
        // Mostra o nome da categoria associada

        System.out.println("Quantidade em Estoque: " + estoque.getQuantidade());
        // Mostra a quantidade disponível no estoque
    }
}