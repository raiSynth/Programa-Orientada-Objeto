/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalhopratico;

public class Estoque {
// Classe que representa o estoque do sistema

    private static int contador = 1;
    // Atributo que gera IDs automáticos

    private int idEstoque;
    // Armazena o ID do estoque

    private int quantidade;
    // Armazena a quantidade atual

    private int estoqueMinimo;
    // Armazena a quantidade mínima permitida

    public Estoque(int quantidade, int estoqueMinimo) {
    // Construtor da classe

        this.idEstoque = contador++;
        // Define o ID automaticamente

        this.quantidade = quantidade;
        // Define a quantidade inicial

        this.estoqueMinimo = estoqueMinimo;
        // Define o estoque mínimo
    }

    public int getIdEstoque() {
    // Retorna o ID do estoque
        return idEstoque;
    }

    public int getQuantidade() {
    // Retorna a quantidade atual
        return quantidade;
    }

    public void adicionarEstoque(int quantidade) {
    // Adiciona quantidade ao estoque
        this.quantidade += quantidade;
    }

    public void removerEstoque(int quantidade) {
    // Remove quantidade do estoque se houver disponível
        if (quantidade <= this.quantidade) {
            this.quantidade -= quantidade;
        } else {
            System.out.println("Quantidade insuficiente.");
        }
    }

    public void atualizarEstoque(int novaQuantidade, int novoMinimo) {
    // Atualiza a quantidade e o estoque mínimo
        this.quantidade = novaQuantidade;
        this.estoqueMinimo = novoMinimo;
    }

    public void exibirInfo() {
    // Exibe as informações do estoque
        System.out.println("ID: " + idEstoque);
        System.out.println("Quantidade: " + quantidade);
        System.out.println("Estoque Mínimo: " + estoqueMinimo);
    }
}