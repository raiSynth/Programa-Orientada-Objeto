/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalhopratico;

public class Categoria {
// Classe que representa uma categoria

    private static int contador = 1;
    // Atributo que gera IDs automáticos

    private int idCategoria;
    // Armazena o ID da categoria

    private String nomeCategoria;
    // Armazena o nome da categoria

    public Categoria(String nomeCategoria) {
    // Construtor da classe

        this.idCategoria = contador++;
        // Define o ID automaticamente

        this.nomeCategoria = nomeCategoria;
        // Define o nome da categoria
    }

    public int getIdCategoria() {
    // Retorna o ID da categoria
        return idCategoria;
    }

    public String getNomeCategoria() {
    // Retorna o nome da categoria
        return nomeCategoria;
    }

    public void atualizarCategoria(String novoNome) {
    // Atualiza o nome da categoria
        this.nomeCategoria = novoNome;
    }

    public void exibirInfo() {
    // Exibe as informações da categoria
        System.out.println("ID: " + idCategoria);
        System.out.println("Nome Categoria: " + nomeCategoria);
    }
}