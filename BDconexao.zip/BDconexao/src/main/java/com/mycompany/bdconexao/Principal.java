/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bdconexao;
import java.sql.Connection;

public class Principal {

    public static void main(String[] args) {

       BDconexao conexao = new BDconexao();

        Connection conn = conexao.conectar();

        if (conn != null) {
            System.out.println("Conexão realizada com sucesso!");
        } else {
            System.out.println("Falha ao conectar ao banco de dados.");
        }
    }
}
