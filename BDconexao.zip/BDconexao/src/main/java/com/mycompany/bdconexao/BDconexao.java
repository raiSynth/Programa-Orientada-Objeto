/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bdconexao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BDconexao {

    // Dados de conexão
    private String url = "jdbc:mysql://127.0.0.1:3306/Teste";
    private String usuario = "root";
    private String senha = "Raissa2005";

    public Connection conectar() {
        Connection conn = null;

        try {
            // Carregar o driver do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Estabelecer conexão
            conn = DriverManager.getConnection(url, usuario, senha);

        } catch (ClassNotFoundException e) {
            System.out.println("Driver JDBC não encontrado.");
            e.printStackTrace();

        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco de dados.");
            e.printStackTrace();

        } catch (Exception e) {
            System.out.println("Erro inesperado.");
            e.printStackTrace();
        }

        return conn;
    }
}